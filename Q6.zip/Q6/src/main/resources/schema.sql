CREATE TABLE buses (
    id INT AUTO_INCREMENT PRIMARY KEY,
    busname VARCHAR(255) NOT NULL,
    location VARCHAR(255) NOT NULL,
    ticket_price DOUBLE NOT NULL
);